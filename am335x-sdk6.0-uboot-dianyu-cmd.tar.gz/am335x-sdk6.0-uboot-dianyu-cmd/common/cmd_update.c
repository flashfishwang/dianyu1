#include <common.h>
#include <net.h>
#include <command.h>
#include <asm/arch/hardware.h>
#include <asm/io.h>
#include <config_cmd_default.h>

/*ROM type number*/
#define EXIT_SELECT_ROM_TYPE	'0'
#define	MT29F2G08	'1'
#define MT29F8G08 '2'
#define EMMC_4G '3'

/*update type*/
#define EXIT_SELECT_UPDATE	'0'
#define UPDATE_ALL	'1'
#define UBOOT_IMG 	'2'
#define KERNEL_IMG 	'3'
#define FS_IMG 		'4'
#define DELETE_ALL	'5'
#define FORMAT_DISK	'6'

void format_disk(void)
{
	run_command("nand scrub.chip",0);
}

void reboot_uboot(void)
{
	run_command("reset",0);
}
void erase_whole_chip_29f2g08(void)
{
	run_command("nand erase.chip",0);
}

void update_mlo_29f2g08(void)
{
	run_command("mmc rescan",0);
	run_command("fatload mmc 0 0x81000000 MLO",0);
	run_command("nand erase 0 0x1ffff",0);
	run_command("nand write 0x81000000 0x0 ${filesize}",0);	
}

void update_uboot_29f2g08(void)
{
	run_command("mmc rescan",0);
	run_command("fatload mmc 0 0x81080000 u-boot.img",0);
	run_command("nand erase 0x80000 0x1dffff",0);
	run_command("nand write 0x81080000 0x80000 ${filesize}",0);	
}

void update_boot_29f2g08(void)
{
	update_mlo_29f2g08();
	update_uboot_29f2g08();
}

void update_kernel_29f2g08(void)
{
	run_command("mmc rescan",0);
	run_command("fatload mmc 0 0x81280000 uImage",0);
	run_command("nand erase 0x280000 0x4fffff",0);
	run_command("nand write 0x81280000 0x280000 ${filesize}",0);	
}

void update_fs_29f2g08(void)
{
	run_command("mmc rescan",0);
	run_command("fatload mmc 0 0x81780000 ubi-29f2g08.img",0);
	run_command("nand erase 0x780000 0xf87ffff",0);
	run_command("nand write 0x81780000 0x780000 ${filesize}",0);		
}

void update_uboot(char type)
{
	switch(type)
	{
	case MT29F2G08:
		update_boot_29f2g08();
		break;
	
	default:
		printf("ERRER! Can't update bootloader!\n");
		break;
	}
}

void update_kernel(char type)
{
	switch(type)
	{
	case MT29F2G08:
		update_kernel_29f2g08();
		break;
	
	default:
		printf("ERRER! Can't update bootloader!\n");
		break;
	}
}

void update_fs(char type)
{
	switch(type)
	{
	case MT29F2G08:
		update_fs_29f2g08();
		break;
	
	default:
		printf("ERRER! Can't update bootloader!\n");
		break;
	}
}

int update_whole_29f2g08(void)
{
	erase_whole_chip_29f2g08();
	update_boot_29f2g08();
	update_kernel_29f2g08();
	update_fs_29f2g08();
	return 1;
}


int update_menu(char type)
{
	char c;
	do
	{
		printf("----------------------Update ROM Menu-----------------------\n");
		printf("0 -- Exit To Select ROM Type Menu\n");
		printf("1 -- Update Whole Linux (MLO,u-boot.img,uImage and ubi.img)\n");	
		printf("2 -- Update Linux Bootloader(MLO and u-boot.img)\n");
		printf("3 -- Update Linux Kernel (uImage)\n");
		printf("4 -- Update Linux Filesystem (ubi.img)\n");
		printf("5 -- Delete Whole Linux\n");
		printf("6 -- Format Whole Disk\n");
		printf("------------------------------------------------------\n");

	HERE:
		printf(":");
		c = getc();

		printf("%c\n",c);
		
		switch(c)
		{
		case EXIT_SELECT_UPDATE:
			return 0;
			break;
		case UBOOT_IMG:
			update_uboot(MT29F2G08);
			break;

		case KERNEL_IMG:
			update_kernel(MT29F2G08);
			break;
	
		case FS_IMG:
			update_fs(MT29F2G08);
			break;
		
		case UPDATE_ALL:
			do_update_whole_29f2g08();
			break;

		case DELETE_ALL:
			erase_whole_chip_29f2g08();
			break;

		case FORMAT_DISK:
			format_disk();
			break;

		default:
			printf("incorrect number\n");
			goto HERE;

		}	
	}while(1);
	
	return 0;
}

int do_update_rom(cmd_tbl_t *cmdtp, int flag, int argc, char *argv[])  
{ 
	char type;

	if(argc >1)
		goto err;
	do
	{
		printf("----------------------Select ROM Type-----------------------\n");
		printf("0 -- Exit To Commond Line\n");
		printf("1 -- 29f2g08(256M Bytes NandFlah)\n");
		printf("------------------------------------------------------\n");
		
	HERE:
		printf(":");
		type = getc();

		printf("%c\n",type);
		
		switch(type)
		{
		case EXIT_SELECT_ROM_TYPE:
			return 0;
			break;
		case MT29F2G08:
			update_menu(type);
			break;
		default :
			printf("Please Select ROM type\n");
			goto HERE;
		}
	}while(1);
	return 0;
err:
	printf ("wrong argv\n");
	return 1;
}


int do_update_whole_29f2g08(cmd_tbl_t *cmdtp, int flag, int argc, char *argv[])
{
	update_whole_29f2g08();
	return 1;
}

U_BOOT_CMD(
        update_rom ,      1,      1,      do_update_rom,
        "set extra parameters\n",
        ""
);

U_BOOT_CMD(
        update_whole_29f2g08 ,      1,      1,      do_update_whole_29f2g08,
        "Sail335 update rom\n",
        ""
);

